"""Answers a whole exam question: text in, chosen option and worked solution out.

    answer(text, read) -> {'answer', 'option', 'status', 'explanation', 'facts'}

read(list of token lists) -> list of fact texts is the reader model (or any function standing in for it). Handles
relation, who, how-many, gender and pair questions, statements to check ("which is definitely true"), data
sufficiency, and coded "which expression shows..." questions (each option is read on its own).
"""
from __future__ import annotations

import collections
import os
import re

from .engine import alternatives, claim_holds, pair_holds, solve
from .explain import explain, match_option
from .facts import FOCUS, parse
from .kin import paths_of
from .names import name_priors
from .prepare import prepare

CANT = re.compile(r"cannot be determined|can.?t be determined|data (?:is )?inadequate|insufficient|not possible to determine|"
                  r"cannot be established|can.?t say", re.I)
NONE = re.compile(r'none of (?:these|the above)', re.I)
NOREL = re.compile(r"\bno (?:blood |family )?relation|\bnot (?:at all )?related\b|\bunrelated\b|\bstrangers?\b", re.I)
NUM_WORDS = {w: i for i, w in enumerate('zero one two three four five six seven eight nine ten eleven twelve'.split())}
SYN = {'dad': 'father', 'mom': 'mother', 'mum': 'mother', 'grand father': 'grandfather', 'grand mother': 'grandmother',
       'grand son': 'grandson', 'grand daughter': 'granddaughter', 'in law': 'in-law', 'cousin brother': 'cousin',
       'cousin sister': 'cousin', 'great grand': 'great-grand', 'grand nephew': 'grand-nephew', 'grand niece': 'grand-niece'}


# ---------- options ----------

def option_moves(text: str):
    """A relation option as steps: "Sister of father-in-law" / "wife's father's sister" -> [(move, gender)];
    None when it is not a chain of relation words."""
    t = ' ' + text.lower().strip(' .') + ' '
    for a, b in SYN.items():
        t = t.replace(f' {a} ', f' {b} ').replace(f' {a}-', f' {b}-').replace(f'{a} ', f'{b} ')
    t = re.sub(r"\b(his|her|my|the|a|an|their|either)\b", ' ', t)
    parts = [p.strip() for p in t.split(' of ') if p.strip()][::-1]   # "x of y" -> y then x
    words = []
    for part in parts:
        for w in part.split("'s"):
            w = w.strip()
            if w:
                words.append(w)
    steps = []
    for w in words:
        toks = w.split()
        side = toks[0] if toks and toks[0] in ('paternal', 'maternal') else None
        word = '-'.join(toks[1:] if side else toks).replace('--', '-')
        paths = paths_of(word, side)
        if not paths:
            return None
        for st in paths[0]:
            steps += [('U', None), ('D', st.g)] if st.m == 'B' else [(st.m, st.g)]
    return steps or None


def _same_path(moves, ans_moves) -> bool:
    if len(moves) != len(ans_moves):
        return False
    return all(m == am and (g is None or g == ag) for (m, g), (am, ag) in zip(moves, ans_moves))


def _side_ok(a, text, status):
    """An option naming the other side ("Maternal uncle" for a paternal one) does not match a settled side."""
    t = text.lower()
    side = a.get('side')
    return not (side and status != 'side' and ('paternal' in t or 'maternal' in t) and side not in t)


def _relation_option(cands, options, status):
    """First answer (in order of preference) that some option names, by word or by spelled-out path."""
    if status == 'assumed' or (cands and cands[0].get('assumed')):   # only a name suggests the gender: an option leaving it open is the setter's intent
        a0 = next((a for a in cands if a.get('key') not in (None, 'none')), None)
        neutral = [(m, None) for m, _, _ in (a0 or {}).get('moves') or []]
        for lab, text in options if neutral else []:
            alts = [option_moves(x) for x in re.split(r'\s+or\s+|/', text)]
            if len(alts) > 1 and all(alts) and all(_same_path([(m, None) for m, _ in x], neutral) for x in alts):
                return a0, lab
        if a0 and _labelled(options, CANT) and not NAMES_DECIDE:
            return a0, _labelled(options, CANT)
    real = [a for a in cands if a.get('key') not in (None, 'none') and a.get('moves')]
    if status in ('conditional', 'ambiguous', 'gender', 'side') and len(real) > 1:   # "Grandfather or Grandmother" names every reading
        for lab, text in options:
            alts = [option_moves(x) for x in re.split(r'\s+or\s+|/', text)]
            if len(alts) > 1 and all(alts):
                paths = [[(m, g) for m, g, _ in a['moves']] for a in real]
                if all(any(_same_path(x, pth) for x in alts) for pth in paths) and all(any(_same_path(x, pth) for pth in paths) for x in alts):
                    return real[0], lab
    for a in cands:
        if a.get('key') in (None, 'none'):
            continue
        fit = [(l, t) for l, t in options if _side_ok(a, t, status)]
        lab = match_option(a.get('label') or a['key'], fit) or match_option(a.get('base') or a['key'], fit)
        if lab:
            return a, lab
        am = [(m, g) for m, g, _ in a.get('moves') or []]
        for lab, text in options:
            for alt in re.split(r'\s+or\s+|/', text):
                mv = option_moves(alt)
                if mv and _same_path(mv, am):
                    return a, lab
            alts = [option_moves(x) for x in re.split(r'\s+or\s+|/', text)]
            if status == 'gender' and len(alts) > 1 and all(alts):   # "Grandson or granddaughter"
                neutral = [(m, None) for m, _ in am]
                if all(_same_path([(m, None) for m, _ in x], neutral) for x in alts):
                    return a, lab
    if not _labelled(options, CANT):   # gender open, one option fits one of its readings ("Sister" for a sibling)
        for a in cands:
            if a.get('key') in (None, 'none') or not a.get('moves'):
                continue
            neutral = [(m, None) for m, _, _ in a['moves']]
            fit = {lab for lab, text in options for alt in re.split(r'\s+or\s+|/', text)
                   if (mv := option_moves(alt)) and _same_path([(m, None) for m, _ in mv], neutral)}
            if len(fit) == 1:
                return a, fit.pop()
    return None, None


def _labelled(options, regex):
    return next((lab for lab, t in options if regex.search(t)), None)


def _names_in(text, ents):
    """Placeholders an option names ("A and C", "P, Q")."""
    byname = {e['text'].lower(): e['id'] for e in ents}
    toks = re.findall(r"[A-Za-z][\w-]*", text)
    found = [byname[t.lower()] for t in toks if t.lower() in byname]
    return found


def _number(text):
    m = re.search(r'\d+', text)
    if m:
        return int(m.group(0))
    for w, n in NUM_WORDS.items():
        if re.search(rf'\b{w}\b', text.lower()):
            return n
    return None


ROMAN = {'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6}


def _roman_set(text):
    t = text.lower()
    if re.search(r'\ball\b', t):
        return 'all'
    if re.search(r'\bnone\b|\bneither\b', t):
        return set()
    return {ROMAN[r] for r in re.findall(r'\b(i{1,3}|iv|vi?)\b', t) if r in ROMAN} or {int(n) for n in re.findall(r'\b\d\b', t)}


# ---------- the answer ----------

NAMES_DECIDE = os.environ.get('KIN_NAMES_DECIDE', '1') == '1'   # a name's gender is taken as given (real exam keys: +8 of 576 dev questions vs preferring 'cannot be determined')
NEAREST = os.environ.get('KIN_NEAREST', '1') == '1'   # still nothing: the closest option by generation, gender and kind
INVERSE = os.environ.get('KIN_INVERSE', '1') == '1'   # no option names the answer but one names the reverse relation: take it
RELAX = os.environ.get('KIN_RELAX', '1') == '1'   # a self-contradictory question still gets the answer its keys expect
DESC_UNNAMED = os.environ.get('KIN_DESC_UNNAMED', '1') == '1'   # described people may turn out to be someone named
COVER = os.environ.get('KIN_COVER', '0') == '1'   # vote weight: readings must use every named person
SMALLEST = os.environ.get('KIN_SMALLEST', '0') == '1'   # smallest family for every spoken description (dev +1.1, locked test -0.4 with r3); off: exact speech readings only
# Answer-time options, off until a dev run (eval.rescore_trace) shows they help:
CLOSURE = os.environ.get('KIN_CLOSURE', '0') == '1'   # "not related" with unnamed relatives: everyone named is one family
CORE_REPAIR = os.environ.get('KIN_CORE_REPAIR', '0') == '1'   # every reading contradicts: drop one fact of a minimal conflict
LEVER = os.environ.get('KIN_LEVER', '0') == '1'   # verifier probability times the reader's weight (LEVER), not instead of it
KEEP_FIRST = os.environ.get('KIN_KEEP_FIRST', '0') == '1'   # adaptive re-read that fails (no family, nothing asked) keeps the first answer
TRACE_POW = float(os.environ.get('KIN_TRACE_POW', '0'))   # vote weight times traceability ** TRACE_POW (0: off)


def answer(text: str, read, priors: dict | None = None) -> dict:
    """Never raises: a failure comes back as status 'error' with the reason."""
    try:
        return _answer(text, read, priors)
    except Exception as e:   # one odd question must not stop a batch or the page
        return {'answer': 'error', 'option': None, 'status': 'error', 'explanation': f'{type(e).__name__}: {e}', 'facts': ''}


def answer_adaptive(text: str, read, read_more, threshold: float = 0.6, priors: dict | None = None) -> dict:
    """More readings only where the first ones disagree (test-time compute where it is needed, Snell et al. 2024):
    answer with `read`; when the winning option holds less than `threshold` of the vote or nothing fits, answer again
    with `read_more` (a wider beam plus samples)."""
    first = answer(text, read, priors)
    if first.get('status') not in ('error', 'none', 'contradiction') and first.get('confidence', 1.0) >= threshold:
        return first
    second = answer(text, read_more, priors)
    bad = ('error', 'none', 'contradiction') if KEEP_FIRST else ('error',)
    return second if second.get('status') not in bad else first


def with_draft(tokens, draft: str, verdict: str):
    """Correction input (build_corrections.py): the question, then a draft reading and the engine's verdict on it."""
    return list(tokens) + ['draft', ':'] + draft.split() + ['check', ':', verdict]


def answer_corrected(text: str, read, threshold: float = 0.6, priors: dict | None = None, rounds: int = 3, first=None) -> dict:
    """Re-read and correct: when no family fits the readings or the winning option holds less than `threshold` of
    the vote, the reader reads again with its draft and the engine's verdict in view (a reader trained on
    build_corrections.py rows), up to `rounds` times, each round from the newest draft. Stops at the first confident
    answer; else the most confident answer that fits (the first reading when none does). `first(text)` gives the
    first answer (e.g. answer_adaptive); default answer(text, read)."""
    fails = ('error', 'none', 'contradiction')
    main = prepare(text)['tokens']
    cur = best = first(text) if first else answer(text, read, priors)
    seen = set()
    for _ in range(rounds):
        status = cur.get('status')
        if status == 'error' or (status not in fails and cur.get('confidence', 1.0) >= threshold):
            return cur
        draft = (cur.get('facts') or '').split('  [')[0].strip()
        if not draft or draft in seen:   # nothing to correct, or the reader repeats itself
            break
        seen.add(draft)
        verdict = 'contradiction' if status in fails else 'unsure'
        cur = answer(text, lambda batch, d=draft, v=verdict: read([with_draft(t, d, v) if t == main else t for t in batch]), priors)
        if cur.get('status') not in fails and (best.get('status') in fails or cur.get('confidence', 0.0) > best.get('confidence', 0.0)):
            best = cur
    return cur if cur.get('status') not in fails and cur.get('confidence', 1.0) >= threshold else best


_VERIFIER = []


def _verifier():
    if not _VERIFIER:
        from .verifier import Verifier
        _VERIFIER.append(Verifier.load(os.environ.get('KIN_VERIFIER')))
    return _VERIFIER[0]


_SOLVED = {}   # (question, reading) -> engine result: batched rounds (eval/batched.py) re-run questions


def candidates(text: str, read, priors: dict | None = None):
    """(prepared question, [(engine result, reader score)]) for every reading."""
    from .codes import with_codes
    p = prepare(text)
    read = with_codes(read, p)   # coded questions are read exactly; the model reads the rest
    got = read([p['tokens']])[0]
    readings = [(got, 0.0)] if isinstance(got, str) else [(g, 0.0) if isinstance(g, str) else (g[0], g[1]) for g in got]
    results = []   # the same reading from several readers (whole, sentence search, simplified) is solved once
    solved = _SOLVED if priors is None else {}
    flags = (NAMES_DECIDE, NEAREST, INVERSE, RELAX, DESC_UNNAMED, SMALLEST, CLOSURE)   # what solving one reading reads
    for k, (lf, score) in enumerate(readings):
        lf = (text, lf, flags)
        if lf not in solved:
            f = lf[1]
            try:
                res = _answer_one(p, f, read, priors)
                if CLOSURE:
                    res = _closure(p, f, read, priors, res)
            except Exception as e:   # one bad reading drops out of the vote, not the whole question
                res = {'answer': 'error', 'option': None, 'status': 'error', 'explanation': f'{type(e).__name__}: {e}', 'facts': f}
            res['trace'] = traceability(p, f)
            if len(solved) >= 100_000:
                solved.clear()
            solved[lf] = res
        res = dict(solved[lf])   # top-level keys only are set per reading
        res['reading'] = k
        results.append((res, score))
    return p, results


def _closure(p, lf, read, priors, res):
    """A question that asks how two named people are related presupposes a link. When the engine finds none but the
    reading has unnamed relatives ("has two children", "her only brother"), read everyone named as one family, as a
    closed-family puzzle states outright, and keep that answer when it fits. Not when "no relation" is an option."""
    if res.get('status') != 'unrelated' or re.search(r'\bmembers\b', lf) or not re.search(r'#\d+|\bhas\b', lf):
        return res
    if any(NOREL.search(t) for _, t in p['options'] or []):
        return res
    stmts = [s.strip() for s in lf.split(';') if s.strip()]
    named = len({t for t in p['tokens'] if re.fullmatch(r'@\d+', t)})
    q = [s for s in stmts if s.split()[0] in QFACTS]
    alt = ' ; '.join([s for s in stmts if s not in q] + [f'members {named}'] + q)
    got = _answer_one(p, alt, read, priors)
    if got.get('status') in ('error', 'contradiction', 'none', 'unrelated'):
        return res
    return {**got, 'via': 'closure'}


def _contradicts(p, stmts, read, priors) -> bool:
    try:
        return _answer_one(p, ' ; '.join(stmts), read, priors).get('status') == 'contradiction'
    except Exception:
        return False


def _core_repair(p, results, read, priors, max_readings: int = 3, max_facts: int = 40):
    """Every reading failed. For the best contradictory readings, find a minimal set of facts that cannot hold together
    (deletion filtering, as QuickXplain; minimal-core repair, arXiv 2608.14771) and answer without each fact of that
    set in turn: a misread fact sits in the core. Returns the consistent variants as (result, reader score)."""
    out, tried = [], 0
    for r, sc in sorted(results, key=lambda x: -x[1]):
        if r.get('status') != 'contradiction' or not r.get('facts') or tried >= max_readings:
            continue
        tried += 1
        parts = [s.strip() for s in r['facts'].split('  [')[0].split(';') if s.strip()]
        qi = [i for i, s in enumerate(parts) if s.split()[0] in QFACTS]
        core = [i for i in range(len(parts)) if i not in qi]
        if not qi or len(core) > max_facts:
            continue
        for i in list(core):
            trial = [j for j in core if j != i]
            if _contradicts(p, [parts[j] for j in trial + qi], read, priors):
                core = trial
        for i in core:
            alt = ' ; '.join(s for j, s in enumerate(parts) if j != i)
            got = _answer_one(p, alt, read, priors)
            if CLOSURE:
                got = _closure(p, alt, read, priors, got)
            if got.get('status') not in ('error', 'contradiction', 'none'):
                out.append(({**got, 'via': 'core-repair', 'dropped': parts[i], 'core': [parts[j] for j in core],
                             'reading': r.get('reading'), 'trace': r.get('trace')}, sc))
    linked = [v for v in out if v[0].get('status') != 'unrelated']
    if CLOSURE and linked and not any(NOREL.search(t) for _, t in p['options'] or []):
        out = linked   # the question presupposes a link (see _closure)
    return out


def traceability(p, lf) -> float | None:
    """Share of the reading's facts between two named people that one sentence of the question names together (a
    sentence opening with a pronoun counts with the one before). Facts the text never states in one place are often
    invented; fully traceable readings are nearly always right (arXiv 2606.27281). None without such facts."""
    sents = [s for s in _sentences(list(p['tokens'])) if '?' not in s]   # the question names both people: no evidence
    spans = [set(s) | (set(sents[i - 1]) if i and s and s[0] in ('he', 'she', 'his', 'her', 'they', 'their') else set())
             for i, s in enumerate(sents)]
    pairs = []
    for st in (lf or '').split('  [')[0].split(';'):
        ws = st.split()
        people = [w for w in ws if re.fullmatch(r'@\d+', w)]
        if ws and ws[0] not in QFACTS and len(people) == 2:
            pairs.append(people)
    if not pairs:
        return None
    return round(sum(any(a in s and b in s for s in spans) for a, b in pairs) / len(pairs), 3)


CLAIM_CUE = re.compile(r'\b(?:true|false|correct|incorrect|statements?|conclusions?|follows?|definitely|derived|inferred|sufficient|necessary|implies)\b')


def _plain_question(p) -> bool:
    """No options and no statements to judge ("Raju is Ashok's friend ... How is Ashok related to Sita?"). With options a
    claim reading still picks one (dev: same score either way, so option questions keep the old vote)."""
    return not p['options'] and not CLAIM_CUE.search(p['question'].lower())


def _answer(text: str, read, priors: dict | None = None) -> dict:
    """read may return one reading per question or several, best first, optionally with scores (mean log-probability
    per token). Every reading is solved; readings that fail (contradiction, no question) drop out; the rest vote for
    their option, weighted by the reader's confidence. confidence: the winning option's share of the votes."""
    import math
    p, results = candidates(text, read, priors)
    good = [(r, sc) for r, sc in results if r['status'] not in ('error', 'contradiction', 'none')]
    if good and _plain_question(p):   # "how is X related to Y?" has no statements to check: a claim reading is a misreading
        kept = [(r, sc) for r, sc in good if r['status'] not in ('claims', 'sufficiency')]
        if not kept:
            return {'answer': 'no reading', 'option': None, 'status': 'none', 'confidence': 0.0, 'facts': good[0][0].get('facts', ''),
                    'explanation': 'every reading checked statements this question does not have'}
        good = kept
    if not good and CORE_REPAIR:
        good = _core_repair(p, results, read, priors)
    if not good:
        return {**results[0][0], 'confidence': 0.0}
    top = max(sc for _, sc in good)
    weights = [math.exp(8 * (sc - top)) for _, sc in good]   # sharper than the raw per-token average
    v = _verifier()
    if v:   # learned verifier (kinlogic/verifier.py): probability each reading is right
        from .verifier import features
        key = lambda r: r['option'] if p['options'] else r['answer']
        cnt = collections.Counter(key(r) for r, _ in good)
        base = weights
        weights = [v.prob(features(p, r, sc, top, cnt[key(r)] / len(good), i, len(good))) for i, (r, sc) in enumerate(good)]
        if LEVER:
            weights = [a * b for a, b in zip(weights, base)]
    if TRACE_POW:
        weights = [wt * max(r['trace'] if r.get('trace') is not None else 1.0, 0.05) ** TRACE_POW
                   for (r, _), wt in zip(good, weights)]
    if COVER:   # a reading that leaves a named person of the question out has likely dropped a sentence
        people = {t for t in p['tokens'] if re.fullmatch(r'@\d+', t)}
        weights = [wt * 0.35 ** len(people - set(re.findall(r'@\d+', r.get('facts') or ''))) for (r, _), wt in zip(good, weights)]
    votes = {}
    for (r, _), wt in zip(good, weights):
        key = r['option'] if p['options'] else r['answer']
        if key is not None:
            votes[key] = votes.get(key, 0.0) + wt
    if not votes:
        return {**good[0][0], 'confidence': 0.0}
    best = max(votes, key=lambda k: (votes[k], -next(i for i, (r, _) in enumerate(good) if (r['option'] if p['options'] else r['answer']) == k)))
    winner = next(r for r, _ in good if (r['option'] if p['options'] else r['answer']) == best)
    return {**winner, 'confidence': round(votes[best] / sum(weights), 3)}


def _people(tokens, stmts):
    """Who belongs to a closed family: the placeholders of the member list (the first sentence naming three or more)
    and everyone the facts mention; a stray capitalized word elsewhere is not a member."""
    if not any(s['t'] == 'members' for s in stmts):
        return []
    out, sent = [], []
    for t in tokens + ['.']:
        if t in ('.', '?', '!'):
            if len(set(sent)) >= 3:
                out = list(dict.fromkeys(sent))
                break
            sent = []
        elif t[0] == '@':
            sent.append(t)
    for s in stmts:
        for k in ('x', 'y'):
            if s.get(k, '').startswith('@') and s[k] not in out:
                out.append(s[k])
    return out


def _option_statements(options, ents):
    """Claims for options that are statements about the question's people, or None."""
    from .codes import option_claims
    ids = {e['text']: e['id'] for e in ents if e.get('kind') in ('name', 'letter')}
    return option_claims(options, ids)


ROLE_PAIR = re.compile(r'^\s*([a-z][a-z -]*?)\s*(?:–|-|—|and|/|&)\s*([a-z][a-z -]*?)\s*$', re.I)
PLURAL_ROLE = {'cousins': 'cousin', 'brothers': 'brother', 'sisters': 'sister', 'siblings': 'sibling', 'couple': 'spouse',
               'husband and wife': 'spouse', 'brothers-in-law': 'brother-in-law', 'sisters-in-law': 'sister-in-law'}


def _pair_option(r, stmts, options, ents):
    """For "how is Y related to X?" / "relationship between X and Y": the one option that holds in every family, when
    the options are statements ("P is the husband of T") or role pairs ("Uncle – Niece", "Cousins")."""
    from .codes import _rel as code_rel
    ask = next((st for st in reversed(stmts) if st['t'] == 'ask'), None)
    if ask is None or not r['worlds']:
        return None
    x, y = ask['x'], ask['y']
    ids = {e['text']: e['id'] for e in ents if e.get('kind') in ('name', 'letter')}
    st_claims = _option_statements(options, ents)

    def holds(facts):
        return all(claim_holds(w, facts, r['ids']) is True for w in r['worlds'])

    def rel_fact(a, word, b):   # b is a's WORD
        rr = code_rel(word.strip().lower())
        return None if rr is None else {'t': 'rel', 'x': a, 'r': rr[1], 'side': rr[0], 'y': b, 'neg': False, 'only': False, 'claim': 1}

    ok = []
    if st_claims:
        groups, cur = [], None
        for st in parse(' ; '.join(st_claims))[0]:
            if cur is None or st.get('claim') != cur[0]:
                cur = (st.get('claim'), [])
                groups.append(cur)
            cur[1].append(st)
        labs = [l for l, o in options if not NONE.search(o) and not CANT.search(o)]
        if len(groups) != len(labs):
            return None
        ok = [l for l, (_, fs) in zip(labs, groups) if all(f.get('x') in r['ids'] and (f.get('y', '@x')[0] == '#' or f.get('y') in r['ids']) for f in fs) and holds(fs)]
    else:
        for lab, o in options:
            t = o.strip().lower().rstrip('.')
            if t in PLURAL_ROLE:   # "Cousins": each is the other's
                f1, f2 = rel_fact(x, PLURAL_ROLE[t], y), rel_fact(y, PLURAL_ROLE[t], x)
            elif (m := ROLE_PAIR.match(t)) and code_rel(m.group(1).strip()) and code_rel(m.group(2).strip()):
                f1, f2 = rel_fact(x, m.group(1), y), rel_fact(y, m.group(2), x)   # "Uncle – Niece": the first named (y) is the uncle
            else:
                continue
            if f1 and f2 and x in r['ids'] and y in r['ids'] and holds([f1, f2]):
                ok.append(lab)
    return ok[0] if len(ok) == 1 else None


def _shape(mv):
    """(generations up, gender, by marriage, collateral) of a move path."""
    ms = [m[0] for m in mv]
    return ms.count('U') - ms.count('D'), mv[-1][1], 'S' in ms, any(m == 'U' and 'D' in ms[i + 1:] for i, m in enumerate(ms))


def _nearest_option(a, options):
    """The one option with the answer's generation and gender that best matches its kind (blood or marriage,
    direct or collateral); None unless exactly one is best."""
    if not a.get('moves'):
        return None
    gen, g, aff, coll = _shape(a['moves'])
    g = a.get('gender') or g
    scored = []
    for lab, text in options:
        mv = option_moves(text)
        if not mv:
            continue
        ogen, og, oaff, ocoll = _shape(mv)
        if ogen == gen and (not g or not og or g == og):
            scored.append(((oaff == aff) + (ocoll == coll), lab))
    top = max((sc for sc, _ in scored), default=None)
    best = [lab for sc, lab in scored if sc == top]
    return best[0] if len(best) == 1 else None


def _inverse(stmts, people, priors, smallest):
    """The last asked relation the other way round (y's relation to x), or None."""
    i = max((k for k, st in enumerate(stmts) if st['t'] == 'ask'), default=None)
    if i is None:
        return None
    alt = stmts[:i] + [{**stmts[i], 'x': stmts[i]['y'], 'y': stmts[i]['x']}] + stmts[i + 1:]
    r = solve(alt, people=people, priors=priors, smallest=smallest)
    return r['questions'][-1] if r['ok'] and r['questions'] and r['questions'][-1]['answers'] else None


def _relaxed(stmts, people, priors, smallest):
    """(result, facts) for the first single change that makes contradictory facts consistent: a gendered relation word
    made neutral (wife -> spouse, mother -> parent) or a stated gender dropped; None if no single change does."""
    from .engine import NEUTRAL
    from .kin import KIN
    for i, st in enumerate(stmts):
        if st.get('claim') or st.get('part') or st.get('neg'):
            continue
        if st['t'] == 'rel' and NEUTRAL.get(st['r']) in KIN:
            alt = stmts[:i] + [{**st, 'r': NEUTRAL[st['r']]}] + stmts[i + 1:]
        elif st['t'] == 'gender':
            alt = stmts[:i] + stmts[i + 1:]
        else:
            continue
        r = solve(alt, people=people, priors=priors, smallest=smallest)
        if r['ok'] and r['questions']:
            return r, alt
    return None


def _answer_one(p, lf, read, priors):
    ents, options = p['ents'], p['options']
    priors = {**name_priors(ents), **(priors or {})}
    names = {e['id']: e['text'] for e in ents}
    out = {'facts': lf, 'options': options}
    lf_read = lf
    if DESC_UNNAMED:   # "the boy", "a man": a description, not a name, so facts like "only grandson" may make it someone named
        desc = {e['id'] for e in ents if e.get('kind') == 'desc'}
        lf = re.sub(r'@(\d+)\b', lambda m: f'#{900 + int(m.group(1))}' if m.group(0) in desc else m.group(0), lf)
        names.update({f'#{900 + int(d[1:])}': names[d] for d in desc})
    stmts, _ = parse(lf)
    people = _people(p['tokens'], stmts)
    low = p['question'].lower()
    if options and stmts and not any(st['t'] in ('ask', 'who', 'count', 'gender?', 'pair') or st.get('claim') or st.get('part') for st in stmts) \
            and re.search(r'which (?:of the following|one|among the following)[^?]*\b(?:true|correct|false|incorrect)\b', low):
        cl = _option_statements(options, ents)   # "which of the following statements is not definitely true?" after an exact reading
        if cl:
            stmts = stmts + parse(' ; '.join(cl))[0]

    expr_opts = options and sum(bool(re.search(r'\b[A-Za-z]\s*(?:[^\w\s,.()\'"]{1,2}|\d)\s*[A-Za-z]\b', o)) for _, o in options) * 2 > len(options)
    if any(s.get('claim') for s in stmts) and expr_opts:   # the options are expressions: read each one
        return {**out, **_which_expression(p, stmts, read, priors)}
    if any(s.get('claim') for s in stmts):
        return {**out, **_claims(stmts, options, low, people, priors)}
    if any(s.get('part') for s in stmts):
        return {**out, **_sufficiency(stmts, options, people, priors)}
    spoken = '"' in p['tokens'] and re.search(r'\b(?:said|says|say|told|tells|introduc\w*|pointing|points?)\b', ' '.join(p['tokens']))
    if spoken and not SMALLEST:   # the convention only on readings the exact speech reader wrote (model misreadings: off)
        from .rules import read as read_rules
        from .speech import read as read_speech
        spoken = lf_read in (read_speech(p['tokens']), read_rules(p['tokens']))
    r = solve(stmts, people=people, priors=priors, smallest=bool(spoken))
    if not r['questions']:
        return {**out, 'answer': 'no question found', 'option': None, 'status': 'none', 'explanation': ''}
    if not r['ok'] and RELAX:   # self-contradictory question (a coded chain that makes P both a wife and a mother):
        relaxed = _relaxed(stmts, people, priors, bool(spoken))   # answer with the one gender clash taken out
        if relaxed:
            r, stmts = relaxed
            out['facts'] = out['facts'] + '  [relaxed: one gender clash ignored]'
    if not r['ok']:
        return {**out, 'answer': 'contradiction', 'option': None, 'status': 'contradiction',
                'explanation': 'The facts as read contradict each other.'}
    q = r['questions'][-1]
    qi = len(r['questions']) - 1
    t = q['q']['t']
    if t == 'pair':
        what = q['q']['what']
        ok = []
        for lab, o in options:
            pair = _names_in(o, ents)
            if len(pair) == 2 and r['worlds'] and all(pair_holds(w, what, r['ids'][pair[0]], r['ids'][pair[1]])
                                                      for w in r['worlds'] if pair[0] in r['ids'] and pair[1] in r['ids']):
                ok.append(lab)
        return {**out, 'status': 'pair', 'explanation': f'[CHECKED]: pairs that are {what}: {", ".join(ok) or "none"}',
                'answer': ', '.join(ok) or 'none', 'option': ok[0] if len(ok) == 1 else _labelled(options, NONE)}
    ex = explain(stmts, r, qi, names=names, priors=priors, options=options) if q['answers'] else None
    res = {'status': q['status'], 'explanation': ex['text'] if ex else 'The statements contradict each other.'}
    if not q['answers']:
        return {**out, **res, 'answer': 'contradiction', 'option': _labelled(options, CANT)}
    if t == 'ask':
        cands = list(q['answers'])
        status = 'gender' if q['status'] == 'unique' and cands[0].get('moves') and not cands[0].get('gender') else q['status']
        puzzle = any(s['t'] in ('members', 'couples', 'generations', 'singles') for s in stmts)   # everyone there is one family
        if cands and not puzzle and all(a.get('key') == 'none' or a.get('nonkin') for a in cands):
            nk = cands[0].get('nonkin')   # no family link between them in any family that fits: not related
            lab = (match_option(nk, options) if nk else None) or _labelled(options, NOREL)
            if lab or not options:
                return {**out, **res, 'status': 'unrelated', 'answer': f'not related ({nk})' if nk else 'not related', 'option': lab}
        if spoken and options and any(len(re.split(r'\s+or\s+|/', o)) > 1 for _, o in options):
            r2 = solve(stmts, people=people, priors=priors, smallest=False)   # "Either father or uncle": the setter names every family, not the smallest
            q2 = r2['questions'][-1] if r2.get('ok') and r2.get('questions') else None
            if q2 and q2['status'] in ('conditional', 'ambiguous') and q2['answers']:
                a2, lab2 = _relation_option(list(q2['answers']), [(l, o) for l, o in options if len(re.split(r'\s+or\s+|/', o)) > 1], q2['status'])
                if lab2:
                    return {**out, **res, 'answer': a2.get('label') or a2['key'], 'option': lab2}
        if options and q['status'] == 'gender' and len({a.get('key') for a in cands}) > 1 and _labelled(options, CANT):
            return {**out, **res, 'answer': 'cannot be determined', 'option': _labelled(options, CANT)}   # only a gender the text never gives decides
        a, lab = _relation_option(cands, options, status) if options else (cands[0], None)
        if options and not lab:
            if status in ('conditional', 'ambiguous', 'assumed') and _labelled(options, NONE) and not _relation_option(alternatives(r, qi), options, status)[1]:
                return {**out, **res, 'answer': cands[0].get('label') or cands[0]['key'], 'option': _labelled(options, NONE)}   # the natural reading is not offered
            if status in ('gender', 'conditional', 'ambiguous') and _labelled(options, CANT):
                return {**out, **res, 'answer': 'cannot be determined', 'option': _labelled(options, CANT)}
            a, lab = _relation_option(alternatives(r, qi), options, status)
            if lab:
                res['explanation'] += f"\n[NOTE]: Read with {names.get(a['merged'][1], a['merged'][1])} as the person the text leaves unnamed."
            elif (lab := _pair_option(r, stmts, options, ents)):   # "(a) P is the husband of T", "(b) Uncle – Niece"
                res['explanation'] += '\n[NOTE]: The option that holds in every family that fits.'
                return {**out, **res, 'answer': cands[0].get('label') or cands[0]['key'], 'option': lab}
            elif INVERSE and not _labelled(options, NONE) and not _labelled(options, CANT):
                q2 = _inverse(stmts, people, priors, bool(spoken))   # "How is Riya related to that man? (a) Father": keyed the other way round
                a, lab = _relation_option(list(q2['answers']), options, q2['status']) if q2 else (None, None)
                if lab:
                    res['explanation'] += '\n[NOTE]: No option names this relation; the options name the reverse one.'
                    return {**out, **res, 'answer': a.get('label') or a['key'], 'option': lab}
                lab = _nearest_option(cands[0], options) if NEAREST else None
                if lab:   # "father's cousin" with options Sister / Mother / Mother-in-law / Aunt: the setter's loose "Aunt"
                    res['explanation'] += '\n[NOTE]: No option names this relation exactly; the closest one (same generation, gender and kind) is chosen.'
                    return {**out, **res, 'answer': cands[0].get('label') or cands[0]['key'], 'option': lab}
        a = a or cands[0]
        label = a.get('label') or a['key']
        text_ans = q.get('neutral') or label if q['status'] == 'gender' and a is cands[0] else label
        return {**out, **res, 'answer': text_ans, 'option': lab or (_labelled(options, NONE) if options else None)}
    if t == 'who':
        want = q['answers'][0].get('names', [])
        lab = next((l for l, o in options if want and sorted(_names_in(o, ents)) == sorted(want)), None)
        return {**out, **res, 'answer': ', '.join(names.get(n, n) for n in want) or 'not named', 'option': lab or _labelled(options, NONE)}
    if t == 'count':
        vals = [a['key'] for a in q['answers']]
        if len(vals) > 1 and _labelled(options, CANT):
            return {**out, **res, 'answer': 'cannot be determined', 'option': _labelled(options, CANT)}
        lab = next((l for l, o in options if str(_number(o)) == vals[0]), None)
        return {**out, **res, 'answer': vals[0], 'option': lab}
    if t == 'gender?':
        g = q['answers'][0]['key']
        lab = _labelled(options, re.compile(rf'^\s*{g}\b', re.I)) if g in ('male', 'female') else _labelled(options, CANT)
        return {**out, **res, 'answer': g if g != 'unknown' else 'cannot be determined', 'option': lab}
    if t == 'prof?':   # "What is the profession of X?"
        keys = {a['key'] for a in q['answers']}
        if len(keys) > 1 or 'unknown' in keys:
            return {**out, **res, 'answer': 'cannot be determined', 'option': _labelled(options, CANT)}
        p_ = keys.pop()
        return {**out, **res, 'answer': p_, 'option': next((l for l, o in options if re.fullmatch(rf'\s*{p_}s?\s*\.?', o, re.I)), None)}
    return {**out, **res, 'answer': q['answers'][0]['key'], 'option': None}


def _claims(stmts, options, low, people, priors):
    r = solve(stmts, people=people, priors=priors)
    verdicts = r['claims']
    if re.search(r"cannot be (?:definitely )?true|can.?t be (?:definitely )?true|not (?:definitely|necessarily) true", low):
        want, hits = 'not definitely true', {k for k, v in verdicts.items() if v != 'true'}
    else:
        want = 'false' if re.search(r"\bfalse\b|not true|incorrect|not correct|cannot be derived|can't be derived|not be derived", low) else 'true'
        hits = {k for k, v in verdicts.items() if v == want}
    ans = f"{len(hits)} statement{'s' if len(hits) != 1 else ''} {want}: " + (', '.join(str(k) for k in sorted(hits)) or 'none')
    lab = None
    if 'how many' in low:
        lab = next((l for l, o in options if _number(o) == len(hits)), None)
    elif options and len(stmt_opts := [(l, o) for l, o in options if re.search(r'\b(is|are|was)\b', o) and not NONE.search(o)]) == len(verdicts):
        picked = [l for (l, _), k in zip(stmt_opts, sorted(verdicts)) if k in hits]   # the options are the statements
        lab = picked[0] if len(picked) == 1 else (_labelled(options, NONE) if not picked else None)   # "(d) None of the above"
    else:
        for l, o in options:
            s = _roman_set(o)
            if s == 'all' and hits == set(verdicts) or s == hits:
                lab = l
                break
    lines = [f'[CLAIM {k}]: {v}' for k, v in sorted(verdicts.items())]
    return {'answer': ans, 'option': lab, 'status': 'claims', 'explanation': '\n'.join(lines)}


def settled(r) -> bool:
    """Data sufficiency: one relation with its gender fixed by the statements (not by names); the side may stay open
    ("grandmother" answers "how is P related to Q?", "son or daughter" does not)."""
    if not r['questions'] or not r['questions'][-1]['answers']:
        return False
    q, a = r['questions'][-1], r['questions'][-1]['answers'][0]
    genderless = (a.get('base') or a.get('key') or '').endswith('cousin')   # English has one word for both
    return q['status'] in ('unique', 'side') and (genderless or (bool(a.get('gender')) and not a.get('assumed')))


def _sufficiency(stmts, options, people, priors):
    parts = sorted({s['part'] for s in stmts if s.get('part')})

    def enough(sub):
        return settled(solve(stmts, parts=set(sub), people=people, priors=priors))

    alone = {k: enough([k]) for k in parts}
    together = enough(parts)
    lines = [f"[STATEMENT {k}]: {'sufficient alone' if v else 'not sufficient alone'}" for k, v in alone.items()]
    lines.append(f"[TOGETHER]: {'sufficient' if together else 'not sufficient'}")
    lab = None
    if len(parts) == 2:
        a, b = alone[parts[0]], alone[parts[1]]
        verdict = 'either' if a and b else 'only1' if a else 'only2' if b else 'both' if together else 'neither'
        pats = {'only1': r'(only|alone).*\bi\b(?!i)|\bi\b(?!i).*alone', 'only2': r'(only|alone).*\bii\b|\bii\b.*alone',
                'either': r'either', 'both': r'both|together', 'neither': r'neither|not sufficient|even'}
        lab = next((l for l, o in options if re.search(pats[verdict], o.lower())), None)
    else:
        for l, o in options:
            nums = {int(n) for n in re.findall(r'\d', o)}
            if re.search(r'not sufficient', o.lower()):
                if not together:
                    lab = l
            elif re.search(r'\ball\b', o.lower()) and together and not any(enough(sorted(set(parts) - {k})) for k in parts):
                lab = l
            elif nums and set(nums) <= set(parts) and enough(sorted(nums)):
                lab = lab or l
    return {'answer': lines[-1].split(': ')[1], 'option': lab, 'status': 'sufficiency', 'explanation': '\n'.join(lines)}


def _which_expression(p, stmts, read, priors):
    """ "Which expression shows that M is the maternal uncle of T?": read each option with the code definitions."""
    claim = [s for s in stmts if s.get('claim') and s['t'] == 'rel']
    if not claim:
        return {'answer': 'no claim found', 'option': None, 'status': 'none', 'explanation': ''}
    c = claim[0]
    names = {e['id']: e['text'] for e in p['ents']}
    q = p['question']
    cut = re.search(r'which (?:of the following|one)', q, re.I)
    defs = q[:cut.start()] if cut else q
    texts = [f"{defs} In the expression '{o}', how is {names.get(c['y'], c['y'])} related to {names.get(c['x'], c['x'])}?"
             for _, o in p['options']]
    preps = [prepare(t) for t in texts]
    lfs = [g if isinstance(g, str) else (g[0][0] if isinstance(g[0], tuple) else g[0]) for g in read([pp['tokens'] for pp in preps])]
    ok, maybe, options_ = [], [], p['options']
    for (lab, o), pp, lf in zip(p['options'], preps, lfs):
        by = {e['text']: e['id'] for e in pp['ents']}
        x, y = by.get(names.get(c['x'])), by.get(names.get(c['y']))
        st, _ = parse(lf)
        if x is None or y is None:
            continue
        r = solve(st, people=[e['id'] for e in pp['ents']])
        vs = [claim_holds(w, [{**c, 'x': x, 'y': y, 'claim': 1}], r['ids']) for w in r['worlds']]
        if vs and all(v is True for v in vs):
            ok.append(lab)
        elif vs and all(v is not False for v in vs):
            maybe.append(lab)   # holds once the gender the expression leaves open is the asked one
    if not ok and len(maybe) == 1:
        ok = maybe
    return {'answer': ', '.join(ok) or 'none', 'option': ok[0] if len(ok) == 1 else (_labelled(options_, NONE) if not ok else None),
            'status': 'expression',
            'explanation': f"[CHECKED]: options {', '.join(ok) or 'none'} make {names.get(c['y'])} the {c['r']} of {names.get(c['x'])}"}


def _sentences(tokens: list[str]) -> list[list[str]]:
    """Sentences of a prepared question ('.' outside quotes ends one; the question keeps its '?')."""
    out, cur, quoted = [], [], False
    for t in tokens:
        cur.append(t)
        if t in ('"', '“', '”'):
            quoted = not quoted
        if t in ('.', '?') and not quoted:
            out.append(cur)
            cur = []
    return out + ([cur] if cur else [])


def with_split(read, min_sentences: int = 3):
    """Adds one more reading for long questions: every statement sentence read on its own (followed by the question,
    the shape the reader was trained on), the facts joined with unnamed people renumbered, the question's facts read
    once. A long puzzle is many short statements; the reader drops and mixes facts far less in a short input."""
    def run(batch):
        out = read(batch)
        for b, toks in enumerate(batch):
            sents = _sentences(list(toks))
            if len(sents) < min_sentences or not any(t == '?' for t in sents[-1]):
                continue
            q = sents[-1]
            parts = read([s + q for s in sents[:-1]] + [q])
            facts, n_new, question = [], 0, None
            for k, got in enumerate(parts):
                lf = got if isinstance(got, str) else (got[0] if isinstance(got[0], str) else got[0][0]) if got else ''
                stmts = [s.split() for s in lf.split(';') if s.strip()]
                if k == len(parts) - 1:
                    question = [s for s in stmts if s and s[0] in ('ask', 'who', 'count', 'gender', 'pair', 'prof')]
                    continue
                ren = {}
                for s in stmts:
                    if not s or s[0] in ('ask', 'who', 'count', 'gender', 'pair', 'prof'):
                        continue
                    for i, t in enumerate(s):
                        if t[0] == '#':
                            if t not in ren:
                                n_new += 1
                                ren[t] = f'#{n_new}'
                            s[i] = ren[t]
                    facts.append(' '.join(s))
            if facts and question:
                lf = ' ; '.join(list(dict.fromkeys(facts)) + [' '.join(s) for s in question])
                prev = out[b] if isinstance(out[b], list) else [(out[b], 0.0)]
                top = max((g[1] for g in prev if not isinstance(g, str)), default=0.0)
                out[b] = list(prev) + [(lf, top)]
        return out
    return run


QFACTS = ('ask', 'who', 'count', 'gender', 'pair', 'prof')
WHOLE = ('members', 'couples', 'generations', 'singles')   # facts about the whole family: checked only on full readings


def _readings(got):
    """[(facts, score)] from one read() result, best first."""
    if isinstance(got, str):
        return [(got, 0.0)]
    return [(g, 0.0) if isinstance(g, str) else (g[0], g[1]) for g in got or []]


def focus_input(tokens, sentence) -> list[str]:
    """Whole question, then the one sentence to read (build_focus.py rows; with_split_search(focus=True))."""
    return list(tokens) + [FOCUS] + list(sentence)


_CONSISTENT = {}   # partial readings -> some family fits; beams and re-reads repeat the same ones


def with_split_search(read, k: int = 3, beam: int = 4, min_sentences: int = 3, focus: bool = False, fits=None, base=None):
    """Sentence-level beam search checked by the engine (as SentBS and execution-guided decoding): each statement
    sentence is read on its own (k readings), sentences are joined in order keeping the `beam` most likely joins the
    engine finds consistent, and those whole readings join the vote. A misread sentence usually contradicts the others,
    so the engine picks which reading of it fits. focus: each sentence read with the whole question in view
    (focus_input; needs a reader trained on build_focus.py rows), not just the sentence and the question; the question
    sentence then counts as one more sentence, its own facts kept ("If C is the husband of B, how is C ...").
    fits(tokens): whether one sentence read fits the reader with room to write; a question where one does not, or
    where a sentence read finishes no reading, is left to the other readings (never cut, never joined without it).
    base: reader for the sentence reads (default `read`), so stacked searches do not search inside each other."""
    base = base or read

    def consistent(facts):
        key = ' ; '.join(f for f in facts if f.split()[0] not in WHOLE and f.split()[0] not in QFACTS)
        got = _CONSISTENT.get(key)
        if got is None:
            try:
                stmts, _ = parse(key)
                got = bool(stmts) is False or bool(solve(stmts).get('ok', True))
            except Exception:
                got = True
            if len(_CONSISTENT) >= 200_000:
                _CONSISTENT.clear()
            _CONSISTENT[key] = got
        return got

    def renumber(lf, n, keep_q=False):
        out, ren = [], {}
        for st in (x.split() for x in lf.split(';') if x.strip()):
            if not st or (st[0] in QFACTS and not keep_q):
                continue
            for i, t in enumerate(st):
                if t[0] == '#':
                    if t not in ren:
                        n += 1
                        ren[t] = f'#{n}'
                    st[i] = ren[t]
            out.append(' '.join(st))
        return out, n

    asks = lambda lf: any(x.split()[:1] and x.split()[0] in QFACTS for x in lf.split(';'))

    def run(batch):
        out = read(batch)
        for b, toks in enumerate(batch):
            sents = _sentences(list(toks))
            if len(sents) < min_sentences or not any(t == '?' for t in sents[-1]):
                continue
            q = sents[-1]
            inputs = [focus_input(toks, s) for s in sents] if focus else [s + q for s in sents[:-1]] + [q]
            if fits and not all(fits(x) for x in inputs):
                continue
            parts = [_readings(g) for g in base(inputs)]
            if any(not r or r[0][1] == float('-inf') for r in parts):   # a sentence read that finished nothing
                continue
            question = [x.strip() for x in parts[-1][0][0].split(';') if x.strip().split()[:1] and x.split()[0] in QFACTS]
            if not question:
                continue
            units = parts if focus else parts[:-1]
            beams = [([], 0.0, 0)]
            for u, got in enumerate(units):
                last = focus and u == len(units) - 1
                opts = got[:k]
                if last:   # the question sentence: readings that ask something, unnamed people numbered on
                    opts = [o for o in opts if asks(o[0])] or opts[:1]
                nxt = []
                for facts, sc, n in beams:
                    for lf, s2 in opts:
                        f2, n2 = renumber(lf, n, keep_q=last)
                        nxt.append((facts + f2, sc + s2, n2))
                nxt.sort(key=lambda x: -x[1])
                kept = [c for c in nxt[:beam * k] if consistent(c[0])][:beam]
                beams = kept or nxt[:1]
            prev = out[b] if isinstance(out[b], list) else [(out[b], 0.0)]
            tail = [] if focus else question
            extra = [(' ; '.join(list(dict.fromkeys(f)) + tail), sc / max(1, len(units))) for f, sc, _ in beams]
            out[b] = list(prev) + extra
        return out
    return run


def _merge_exact(exact, ask, lf):
    """A model reading with the clauses the rules understood replaced by their exact facts: model facts about a named
    pair the exact facts cover are dropped, the exact question wins, the rules' unnamed people are renumbered apart."""
    pairs = {frozenset(e) for e in (re.findall(r'[@#]\d+', f) for f in exact) if len(e) == 2}
    keep = []
    for f in lf.split(' ; '):
        e = re.findall(r'[@#]\d+', f)
        if f.startswith(('ask ', 'who ')) and ask:
            continue
        if len(e) == 2 and all(x[0] == '@' for x in e) and frozenset(e) in pairs:
            continue
        keep.append(f)
    return ' ; '.join(exact + keep + ([ask] if ask else []))


def with_exact_clauses(read):
    """Hybrid readings: where the rules understand some clauses of a question but not all, every model reading also
    comes merged with the exact facts of those clauses (one more vote each); the model only has to be right where the
    rules cannot read. +6 of 327 model-read dev questions in an offline test (runs/readings_dev.jsonl)."""
    from .rules import read_partial

    def run(batch):
        out = read(batch)
        for b, toks in enumerate(batch):
            try:
                facts, missed, ask = read_partial(list(toks))
            except Exception:
                continue
            if not facts or not missed:
                continue
            ren = lambda f: re.sub(r'#(\d+)', lambda m: f'#{50 + int(m.group(1))}', f)
            facts, ask = [ren(f) for f in facts], (ren(ask) if ask else None)
            prev = out[b] if isinstance(out[b], list) else [(out[b], 0.0)]
            out[b] = list(prev) + [(_merge_exact(facts, ask, g if isinstance(g, str) else g[0]), g[1] if not isinstance(g, str) else 0.0) for g in prev]
        return out
    return run


_REL_RE = r"(?:the )?(?:only )?(?:paternal |maternal )?[a-z][a-z-]*"
_CLAUSES = [
    # "X is the R of Y , who is the S of Z" -> "X is the R of Y . Y is the S of Z" (who = the nearest person)
    (re.compile(rf"([@#]\d+) (is|was) ({_REL_RE}) of ([@#]\d+) , (?:who|which) (is|was|has) ([^.;?,]+?)(?= [.;?,]|$)"), r"\1 \2 \3 of \4 . \4 \5 \6"),
    # "X , who is the R of Y , is/has ..." -> "X is the R of Y . X is/has ..." (who = the subject)
    (re.compile(r"(^|[.;] )([@#]\d+) , (?:who|which) (is|was|has) ([^.;?,]+?) , (is|was|has|had) "), r"\1\2 \3 \4 . \2 \5 "),
    # "X , whose R is Y , ..." -> "X 's R is Y . X ..."
    (re.compile(r"(^|[.;] )([@#]\d+) , whose ([a-z-]+) is ([@#]\d+) , "), r"\1\2 's \3 is \4 . \2 "),
]


def simplify(tokens):
    """Relative clauses split into plain sentences (sentence decomposition, TACL 2023: natural questions mapped to the
    simple shapes a parser trained on synthetic text reads well). Same meaning; None when nothing changes."""
    text = ' '.join(tokens)
    out = text
    for pat, rep in _CLAUSES:
        for _ in range(4):   # nested clauses
            new = pat.sub(rep, out)
            if new == out:
                break
            out = new
    return out.split() if out != text else None


def with_simplified(read):
    """One more set of readings for questions with relative clauses: the same question with its clauses split into
    plain sentences (exam.simplify), read by the same model; every reading joins the vote."""
    def run(batch):
        out = read(batch)
        idx, alt = [], []
        for b, toks in enumerate(batch):
            s = simplify(list(toks))
            if s:
                idx.append(b)
                alt.append(s)
        if alt:
            got = read(alt)
            for b, g in zip(idx, got):
                prev = out[b] if isinstance(out[b], list) else [(out[b], 0.0)]
                add = g if isinstance(g, list) else [(g, 0.0)]
                out[b] = list(prev) + list(add)
        return out
    return run
